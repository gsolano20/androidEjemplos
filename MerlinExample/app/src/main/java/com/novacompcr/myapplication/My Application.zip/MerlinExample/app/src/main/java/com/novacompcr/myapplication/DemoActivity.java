package com.novacompcr.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.novacompcr.myapplication.base.MerlinActivity;
import com.novoda.merlin.Bindable;
import com.novoda.merlin.Connectable;
import com.novoda.merlin.Disconnectable;
import com.novoda.merlin.Merlin;
import com.novoda.merlin.MerlinsBeard;
import com.novoda.merlin.NetworkStatus;

public class DemoActivity extends MerlinActivity implements Connectable, Disconnectable, Bindable {

   // private NetworkStatusDisplayer networkStatusDisplayer;
    private MerlinsBeard merlinsBeard;
    private View viewToAttachDisplayerTo;
    ValidarConeccion Conectado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      //  viewToAttachDisplayerTo = findViewById(R.id.displayerAttachableView);
        merlinsBeard = new MerlinsBeard.Builder()
                .build(this);
        //networkStatusDisplayer = new NetworkStatusDisplayer(getResources(), merlinsBeard);

        /*
        findViewById(R.id.current_status).setOnClickListener(networkStatusOnClick);
        findViewById(R.id.has_internet_access).setOnClickListener(hasInternetAccessClick);
        findViewById(R.id.wifi_connected).setOnClickListener(wifiConnectedOnClick);
        findViewById(R.id.mobile_connected).setOnClickListener(mobileConnectedOnClick);
        findViewById(R.id.network_subtype).setOnClickListener(networkSubtypeOnClick);
        findViewById(R.id.next_activity).setOnClickListener(nextActivityOnClick);
         */
    }

    private final View.OnClickListener networkStatusOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (merlinsBeard.isConnected()) {
                Toast.makeText(DemoActivity.this,"Conectado",Toast.LENGTH_SHORT).show();
                // networkStatusDisplayer.displayPositiveMessage(R.string.current_status_network_connected, viewToAttachDisplayerTo);
            } else {
                Toast.makeText(DemoActivity.this,"Conectado",Toast.LENGTH_SHORT).show();
            }
        }
    };



    @Override
    protected Merlin createMerlin() {
        return new Merlin.Builder()
                .withConnectableCallbacks()
                .withDisconnectableCallbacks()
                .withBindableCallbacks()
                .build(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerConnectable(this);
        registerDisconnectable(this);
        registerBindable(this);
    }

    @Override
    public void onBind(NetworkStatus networkStatus) {
        /*if (!networkStatus.isAvailable()) {
            onDisconnect();
        }*/
        Conectado=new ValidarConeccion(this);
        if(Conectado.connected){
        }else{
            onDisconnect();
        }
    }

    @Override
    public void onConnect() {
        Toast.makeText(DemoActivity.this,"Conectado",Toast.LENGTH_SHORT).show();
        //networkStatusDisplayer.displayPositiveMessage(R.string.connected, viewToAttachDisplayerTo);
    }

    @Override
    public void onDisconnect() {
        Toast.makeText(DemoActivity.this,"desConectado",Toast.LENGTH_SHORT).show();
        //networkStatusDisplayer.displayNegativeMessage(R.string.disconnected, viewToAttachDisplayerTo);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
