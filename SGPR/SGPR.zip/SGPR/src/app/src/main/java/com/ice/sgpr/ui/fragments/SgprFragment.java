package com.ice.sgpr.ui.fragments;

import android.support.v4.app.Fragment;


public class SgprFragment extends Fragment {

	/*protected void showError(String pErrorMessage)
	{
		if (getView() != null)
		{
			View mainContent = (View) getView().findViewById(R.id.main_content);
			View errorContent = (View) getView().findViewById(R.id.error_content);
			TextView tvError = (TextView) getView().findViewById(R.id.tv_error);
			
			if (mainContent != null && errorContent != null && tvError != null)
			{
				mainContent.setVisibility(View.GONE);
				errorContent.setVisibility(View.VISIBLE);
				tvError.setText(pErrorMessage);
			}
		}
	}*/
}
