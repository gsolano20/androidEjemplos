# imagepickerdemo
This is just a demo of Image Picker through a FileProvider used in Nougat+ devices. It demonstrates how the image will get from camera and the image file path
