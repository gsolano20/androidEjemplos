package com.novoda.merlin;

public interface Connectable extends Registerable {
    void onConnect();
}
