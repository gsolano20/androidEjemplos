package com.novoda.merlin;

interface Registerable {
}
