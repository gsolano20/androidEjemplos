package com.androiddesdecero.ottobus;

/**
 * Created by albertopalomarrobledo on 11/4/18.
 */

public class MessageAtoF {

    private String message;

    public MessageAtoF(String message){
        this.message = message;
    }

    public String getMessage(){
        return message;
    }
}
