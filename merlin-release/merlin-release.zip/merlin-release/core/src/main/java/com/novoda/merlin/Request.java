package com.novoda.merlin;

interface Request {
    int getResponseCode();
}
