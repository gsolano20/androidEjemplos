package com.androiddesdecero.ottobus;

/**
 * Created by albertopalomarrobledo on 11/4/18.
 */

public class MessageFtoF {

    private String message;

    public MessageFtoF(String message){
        this.message = message;
    }

    public String getMessage(){
        return message;
    }
}
