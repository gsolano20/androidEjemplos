package com.novoda.merlin;

interface RequestMaker {
    Request head(Endpoint endpoint);
}
