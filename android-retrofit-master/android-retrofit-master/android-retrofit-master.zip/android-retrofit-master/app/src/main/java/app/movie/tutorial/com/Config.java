package app.movie.tutorial.com;

public class Config {
    public static String PACKAGE_NAME = "app.movie.tutorial.com";
    public final static String IMAGE_URL_BASE_PATH = "http://image.tmdb.org/t/p/w342//";
    public static final String API_BASE_URL = "http://api.themoviedb.org/3/";
    public final static String API_KEY = "YOUR_API_KEY_HERE";

}
