# MaterialTabsWithFab

![First Screen](https://user-images.githubusercontent.com/46577836/67170626-79d1d100-f3b3-11e9-9bde-9e7e2170e50c.png)
![Item – 1](https://user-images.githubusercontent.com/46577836/67170627-7a6a6780-f3b3-11e9-9bbc-b237f5b13ba0.png)
![Item – 2](https://user-images.githubusercontent.com/46577836/67170628-7a6a6780-f3b3-11e9-86c5-47226dcac72c.png)
![Item – 3](https://user-images.githubusercontent.com/46577836/67170629-7a6a6780-f3b3-11e9-8c79-2635e22ba7ba.png)
![Item – 5](https://user-images.githubusercontent.com/46577836/67170630-7a6a6780-f3b3-11e9-8f6b-eaf49fc85e85.png)
![Last Sreen – 2](https://user-images.githubusercontent.com/46577836/67170631-7a6a6780-f3b3-11e9-9cc1-c72fc5496658.png)
