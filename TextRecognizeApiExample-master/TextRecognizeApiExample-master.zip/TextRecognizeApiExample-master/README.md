
This demo contins the code for recognize the text from image through Cloud OCR SDK
For Running this example you need app credential by creating app from register at http://cloud.ocrsdk.com/Account/Welcome 
You should get e-mail from ABBYY Cloud OCR SDK service with the application password
aftrer getting app credential update the following in ResultActivity.java class ,please see the above example demo , this will work perfect to recognize text
public static final String APP_ID  = "textrecognizeappid";
public static final String PASSWORD  = "qDmbzYMMsH6urtyuhtLq449G5";
