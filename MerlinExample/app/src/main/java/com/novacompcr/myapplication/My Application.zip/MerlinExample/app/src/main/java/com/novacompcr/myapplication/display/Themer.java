package com.novacompcr.myapplication.display;

import android.content.res.Resources;
import android.support.design.widget.Snackbar;

interface Themer {

    void applyTheme(Resources resources, Snackbar snackbar);

}
