package com.novoda.merlin;

public interface Disconnectable extends Registerable {
    void onDisconnect();
}
